import json
import boto3
import os
from datetime import datetime

sns = boto3.client('sns')

def handler(event, context):
    try:
        detail = event['detail']
        
        # Extract key information
        event_name = detail.get('eventName', 'Unknown')
        event_time = detail.get('eventTime', 'Unknown')
        user_identity = detail.get('userIdentity', {})
        source_ip = detail.get('sourceIPAddress', 'Unknown')
        user_agent = detail.get('userAgent', 'Unknown')
        request_params = detail.get('requestParameters', {})
        
        # Determine who made the change
        principal_type = user_identity.get('type', 'Unknown')
        if principal_type == 'IAMUser':
            actor = f"IAM User: {user_identity.get('userName', 'Unknown')}"
        elif principal_type == 'AssumedRole':
            actor = f"Role: {user_identity.get('sessionContext', {}).get('sessionIssuer', {}).get('userName', 'Unknown')}"
        elif principal_type == 'Root':
            actor = "Root Account"
        else:
            actor = f"{principal_type}: {user_identity.get('principalId', 'Unknown')}"
        
        # Format the message
        message = f"""
🚨 WAF MODIFICATION ALERT 🚨

ACTION: {event_name}
TIME: {event_time}
WHO: {actor}
SOURCE IP: {source_ip}
USER AGENT: {user_agent}

DETAILS:
{json.dumps(request_params, indent=2)}

AWS ACCOUNT: {detail.get('recipientAccountId', 'Unknown')}
REGION: {detail.get('awsRegion', 'Unknown')}
EVENT ID: {detail.get('eventID', 'Unknown')}

---
This is an automated alert from your WAF monitoring system.
        """
        
        # Send to SNS
        response = sns.publish(
            TopicArn=os.environ['SNS_TOPIC_ARN'],
            Subject=f'🚨 WAF Alert: {event_name} by {actor}',
            Message=message
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps('Alert sent successfully')
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
